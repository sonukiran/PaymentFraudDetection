# main.py
from fastapi import FastAPI
from app.api.FraudDecisionManager import app  # Import the FastAPI app instance from the api_module

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8090)