from typing import List, Optional
from pydantic import BaseModel, Field, ValidationError

"""
class ChannelCustomData(BaseModel):
    channelCustomDataField1: str
    channelCustomDataField2: str
    channelCustomDataField3: str
    channelCustomDataField4: str
    channelCustomDataField5: str
    channelCustomDataField6: str
    channelCustomDataField7: str
    channelCustomDataField8: str
    channelCustomDataField9: str
    channelCustomDataField19: str
    channelCustomDataField20: str


class OrderItem(BaseModel):
    productName: str
    quantity: int
    unitPrice: float


class ShipTo(BaseModel):
    address: dict
    contact: dict
    name: dict
    shippingMethod: str


class OrderInfo(BaseModel):
    channelCustomData: ChannelCustomData
    orderItems: List[OrderItem]
    shipTo: ShipTo


class Address(BaseModel):
    city: str
    country: str
    line1: str
    line2: str
    state: str
    zip: str


class Contact(BaseModel):
    emailAddress: str
    phone: str


class Name(BaseModel):
    firstName: str
    lastName: str


class BillTo(BaseModel):
    address: Address
    contact: Contact
    dateOfBirth: str
    name: Name

"""

"""
class PaymentCard(BaseModel):
    cardNumber: int
    cardType: str
"""


class RequestBody(BaseModel):
    cardNumber: Optional[int]


"""
# Example usage
data = {
    {
        "addInstrumentToWallet": {
            "customerDefinedName": "string",
            "defaultInstrument": true
        },
        "agentId": "string",
        "amount": 96.24,
        "billingInfo": {
            "billingArrangementId": "123",
            "market": "123",
            "region": "string"
        },
        "customerId": "Cust_Traffic1_Cust240311131538_Id3815",
        "enableDecisionManager": true,
        "fee": 0,
        "feeWaivedReason": "string",
        "keyName": "abc",
        "orderInfo": {
            "channelCustomData": {
                "channelCustomDataField1": "string",
                "channelCustomDataField19": "string",
                "channelCustomDataField2": "string",
                "channelCustomDataField20": "string",
                "channelCustomDataField3": "string",
                "channelCustomDataField4": "string",
                "channelCustomDataField5": "string",
                "channelCustomDataField6": "string",
                "channelCustomDataField7": "string",
                "channelCustomDataField8": "string",
                "channelCustomDataField9": "string"
            },
            "orderItems": [
                {
                    "productName": "string",
                    "quantity": 0,
                    "unitPrice": 0
                }
            ],
            "shipTo": {
                "address": {
                    "city": "HUNTSVILLE",
                    "country": "US",
                    "line1": "BRAGG ST",
                    "line2": "3507",
                    "state": "VA",
                    "zip": "35810"
                },
                "contact": {
                    "emailAddress": "raj@openai.com",
                    "phone": "12563772957"
                },
                "name": {
                    "firstName": "Raj",
                    "lastName": "kumar"
                },
                "shippingMethod": "string"
            }
        },
        "paymentCard": {
            "billTo": {
                "address": {
                    "city": "HUNTSVILLE",
                    "country": "US",
                    "line1": "BRAGG ST",
                    "line2": "3507",
                    "state": "VA",
                    "zip": "35810"
                },
                "contact": {
                    "emailAddress": "raj@openai.com",
                    "phone": "12563772957"
                },
                "dateOfBirth": "string",
                "name": {
                    "firstName": "Raj",
                    "lastName": "Kumar"
                }
            },
            "cardNumber": "30569309025904",
            "cardType": "DinersClub",
            "cvv": "111",
            "expirationDate": "1229"
        },
        "secure": false,
        "storeNumber": "123",
        "terminalDetails": {
            "terminalCity": "string",
            "terminalId": "string",
            "terminalState": "string"
        }
    }
}
"""

# Example JSON data
json_data = {
    "cardNumber": 30569309025904
}

# Validate and create an instance of the RequestBody model
try:
    request_body_instance = RequestBody(**json_data)
    print("Validation successful!")
    print(request_body_instance.dict())  # Access the validated data as a dictionary
except ValidationError as e:
    print("Validation error:")
    print(e)
