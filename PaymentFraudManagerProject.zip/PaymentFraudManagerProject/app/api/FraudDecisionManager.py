from fastapi import FastAPI, HTTPException
from app.models.RequestBody import RequestBody
from app.models.ResponseBody import CustomResponse

app = FastAPI()


@app.post("/process", response_model=CustomResponse)
def process_request(data: RequestBody):
    # Process the request data (replace this with your logic)
    try:
        # Your processing logic here
        # For demonstration purposes, just returning DMEnable: true
        return CustomResponse(DMEnable=True)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")
